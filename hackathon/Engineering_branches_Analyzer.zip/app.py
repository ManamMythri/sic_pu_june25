import streamlit as st
import pandas as pd
import plotly.express as px
from analyzer import BranchDemandAnalyzer

# PAGE CONFIG

st.set_page_config(page_title="Engineering Branch Analysis", layout="wide")
st.title(" Engineering Branch Demand Analysis")

# LOAD DATA

DATA_PATH = "data\Engineering_Students_Data.csv"

try:
    data = pd.read_csv(DATA_PATH)
    st.success(f" Loaded data from {DATA_PATH}")
except FileNotFoundError:
    st.error(f" File not found: {DATA_PATH}")
    st.stop()

analyzer = BranchDemandAnalyzer(data)

# Show Raw Data Checkbox

if st.checkbox("Show Raw Data"):
    st.subheader(" Raw Data")
    st.dataframe(analyzer.data)

# Clean Data Button

if st.button(" Clean Data"):
    try:
        analyzer.clean_data()
        st.success(" Data cleaned successfully!")
        st.dataframe(analyzer.data)
    except Exception as e:
        st.error(f" Error: {e}")

# Basic Statistics Button

if st.button(" Show Basic Statistics"):
    st.subheader(" Descriptive Statistics")
    st.dataframe(analyzer.data.describe())


# Latest Year Demand Analysis

if st.button("Analyze Latest Year Demand"):
    try:
        analyzer.get_latest_year_data()
        analyzer.analyze_current_demand()

        st.subheader(f" Latest Year: {analyzer.latest_year}")
        st.dataframe(analyzer.latest_data)

        st.success(f" Highest Demand Branch: {analyzer.highest_demand_branch}")
        st.warning(f" Lowest Demand Branch: {analyzer.lowest_demand_branch}")
    except Exception as e:
        st.error(f" Error: {e}")

# Analyze Branch Trends
if st.button(" Analyze Branch Trends"):
    try:
        analyzer.analyze_trends()

        st.subheader(" Demand Trends (Slope per Branch)")
        st.dataframe(pd.DataFrame(list(analyzer.trends.items()), columns=["Branch", "Slope"]))

        if analyzer.branch_most_growth:
            st.success(f" Branch with Most Growth Potential: {analyzer.branch_most_growth}")

        if analyzer.branch_most_decline:
            st.error(f" Branch More Likely to Decline: {analyzer.branch_most_decline}")
    except Exception as e:
        st.error(f" Error: {e}")

st.header(" Visualize Branch Demand by Year")

#  Select year
available_years = sorted(analyzer.data['year'].unique())
selected_year = st.selectbox(" Select Year", available_years)

#  Filter for selected year
year_data = analyzer.data[analyzer.data['year'] == selected_year]

if year_data.empty:
    st.warning(" No data available for the selected year.")
else:
    st.success(f" Showing data for {selected_year}")

    #  Compute highest and lowest demand branch for this year
    highest_branch = year_data.loc[year_data['studentcount'].idxmax(), 'branch']
    lowest_branch = year_data.loc[year_data['studentcount'].idxmin(), 'branch']

    st.subheader(f" Demand in {selected_year}")
    st.markdown(f" **Highest-demand branch:** `{highest_branch}`")
    st.markdown(f" **Lowest-demand branch:** `{lowest_branch}`")

    #  Also show previous year's highest and lowest
    prev_year = selected_year - 1
    if prev_year in available_years:
        prev_data = analyzer.data[analyzer.data['year'] == prev_year]
        prev_highest = prev_data.loc[prev_data['studentcount'].idxmax(), 'branch']
        prev_lowest = prev_data.loc[prev_data['studentcount'].idxmin(), 'branch']

        st.subheader(f" Demand in {prev_year}")
        st.markdown(f" **Highest-demand branch:** `{prev_highest}`")
        st.markdown(f" **Lowest-demand branch:** `{prev_lowest}`")
    else:
        st.info(f" No data found for previous year ({prev_year})")

    #  pie Chart
    st.subheader(f" Pie Chart of Branch Demand ({selected_year})")
    fig_pie = px.pie(
        year_data,
        names='branch',
        values='studentcount',
        title=f"Branch Share in {selected_year}",
        hole=0.3

    )
    fig_pie.update_layout(width=400, height=600)
    st.plotly_chart(fig_pie, use_container_width=True)

    #  Vertical Bar Chart
    st.subheader(f" Vertical Bar Chart of Branch Demand ({selected_year})")
    fig_bar = px.bar(
        year_data,
        x='branch',
        y='studentcount',
        color='branch',
        title=f"Branch Demand in {selected_year}"
    )
    fig_bar.update_layout(width=400, height=600)
    st.plotly_chart(fig_bar, use_container_width=True)



# placement and salary 
if st.button(" Analyze Placement and Salary"):
    try:
        analyzer.analyze_placement_and_salary()

        st.subheader(" Average Placement Ratio and Salary by Branch")
        st.dataframe(analyzer.placement_stats)

        st.subheader(" Placement Ratio per Branch")
        fig1 = px.bar(
            analyzer.placement_stats,
            x='branch',
            y='placement_ratio',
            color='branch',
            title="Average Placement Ratio by Branch"
        )
        fig1.update_layout(width=400, height=600)
        st.plotly_chart(fig1, use_container_width=True)

        st.subheader(" Average Salary per Branch")
        fig2 = px.bar(
            analyzer.placement_stats,
            x='branch',
            y='avg_salary',
            color='branch',
            title="Average Salary by Branch"
        )
        fig2.update_layout(width=400, height=600)
        st.plotly_chart(fig2, use_container_width=True)

    except Exception as e:
        st.error(f" Error: {e}")


 # CONCLUSION SUMMARY


st.header(" Final Summary: Branch Demand Insights")

try:
    analyzer.get_latest_year_data()
    analyzer.analyze_current_demand()
    analyzer.analyze_trends()

    col1, col2 = st.columns(2)

    with col1:
        st.markdown(f"<h4 style='color: green;'> Latest Year Analyzed: {analyzer.latest_year}</h4>", unsafe_allow_html=True)
        st.markdown(f"<h4 style='color: blue;'> Highest Demand Branch: {analyzer.highest_demand_branch}</h4>", unsafe_allow_html=True)
        st.markdown(f"<h4 style='color: orange;'> Lowest Demand Branch: {analyzer.lowest_demand_branch}</h4>", unsafe_allow_html=True)

    with col2:
        st.markdown(f"<h4 style='color: green;'> Most Likely to Grow: {analyzer.branch_most_growth}</h4>", unsafe_allow_html=True)
        st.markdown(f"<h4 style='color: red;'> Most Likely to Decline: {analyzer.branch_most_decline}</h4>", unsafe_allow_html=True)


   

except Exception as e:
    st.error(f" Failed to generate summary: {e}")
