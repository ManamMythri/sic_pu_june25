import pandas as pd
from scipy.stats import linregress

class BranchDemandAnalyzer:
    def __init__(self, data):
        self.data = data.copy() 
        # Don't read CSV here—just store the DataFrame
        if not isinstance(data, pd.DataFrame):
            raise TypeError(" BranchDemandAnalyzer expects a pandas DataFrame!")
        
        self.data = data.copy()
        self.latest_year = None
        self.latest_data = None
        self.trends = {}
        self.highest_demand_branch = None
        self.lowest_demand_branch = None
        self.branch_most_growth = None
        self.branch_most_decline = None
        self.placement_stats = None

    def clean_data(self):
        required_columns = ['year', 'branch', 'studentcount']
        missing = [col for col in required_columns if col not in self.data.columns]
        if missing:
            raise ValueError(f" Missing columns in CSV: {missing}")

        self.data.dropna(subset=required_columns, inplace=True)
        self.data['year'] = self.data['year'].astype(int)
        self.data['studentcount'] = self.data['studentcount'].astype(int)

        # Handle optional placement and salary columns
        if 'placement_ratio' in self.data.columns:
            self.data['placement_ratio'] = self.data['placement_ratio'].fillna(0).astype(float)
        if 'avg_salary' in self.data.columns:
            self.data['avg_salary'] = self.data['avg_salary'].fillna(0).astype(float)

    def get_latest_year_data(self):
        self.latest_year = self.data['year'].max()
        self.latest_data = self.data[self.data['year'] == self.latest_year]

    def analyze_current_demand(self):
        if self.latest_data.empty:
            raise ValueError(" No data for the latest year!")
        highest_row = self.latest_data.loc[self.latest_data['studentcount'].idxmax()]
        lowest_row = self.latest_data.loc[self.latest_data['studentcount'].idxmin()]
        self.highest_demand_branch = highest_row['branch']
        self.lowest_demand_branch = lowest_row['branch']

    def analyze_trends(self):
        branches = self.data['branch'].unique()
        self.trends = {}
        for branch in branches:
            branch_data = self.data[self.data['branch'] == branch]
            if len(branch_data) < 2:
                self.trends[branch] = None
                continue
            slope, *_ = linregress(branch_data['year'], branch_data['studentcount'])
            self.trends[branch] = slope

        trends_clean = {k: v for k, v in self.trends.items() if v is not None}
        if trends_clean:
            self.branch_most_growth = max(trends_clean, key=trends_clean.get)
            self.branch_most_decline = min(trends_clean, key=trends_clean.get)

    def analyze_placement_and_salary(self):
        if 'placement_ratio' not in self.data.columns or 'avg_salary' not in self.data.columns:
            raise ValueError(" CSV missing 'placement_ratio' or 'avg_salary' columns.")
        self.placement_stats = self.data.groupby('branch').agg({
            'placement_ratio': 'mean',
            'avg_salary': 'mean'
        }).reset_index()
